<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$words =  array(
    'Image Tag' => 'Etiqueta Imagen',
    'Allow Image Tags' => 'Permitir etiquetas Imagen',
);

?>
